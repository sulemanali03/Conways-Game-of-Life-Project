# Final application implementation

## Notes
**Maven must be installed to run this project**

## Compile and run instructions using maven:
> Navigate to part_5_final_implementation directory   
> mvn compile   
> mvn exec:java  


 