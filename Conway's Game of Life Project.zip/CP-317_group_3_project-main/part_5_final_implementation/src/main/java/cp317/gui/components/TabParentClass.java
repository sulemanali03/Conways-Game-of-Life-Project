package cp317.gui.components;

import javax.swing.JPanel;
public class TabParentClass extends JPanel {
    /*
    * Generic tabs class that all other tabs in the side pannel will 
    * inherit from.
    */

    public String title;

    
}
