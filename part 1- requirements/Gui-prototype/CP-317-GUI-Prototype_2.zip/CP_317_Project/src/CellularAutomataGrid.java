import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;
import java.util.Stack;

public class CellularAutomataGrid extends JPanel { // Now extends JPanel
    private static final int GRID_SIZE = 58; 
    private static final int CELL_SIZE = 10;  
    private boolean[][] currentState;
    private Stack<boolean[][]> history;   

    public CellularAutomataGrid() {
        // Initialize the history stack first
        history = new Stack<>();  // Initialize the history stack

        // Then set the preferred size for the grid panel
        setPreferredSize(new Dimension(GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE));

        // Now call the method to initialize the grid state
        initializeStates();  // Initialize grid with all dead cells

        // Add mouse listener for toggling cells
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleGridClick(e);
            }
        });
    }
    
    
    // Initializes the grid with all cells set to dead (false)
    public void initializeStates() {
        currentState = new boolean[GRID_SIZE][GRID_SIZE];
        history.clear();  // Clear the history stack when resetting
        history.push(copyGrid(currentState));  // Store the initial grid state in the history
        repaint();  // Redraw the grid with the initial state (all dead)
    }
    
 // Copy the current grid state (to save it for history)
    private boolean[][] copyGrid(boolean[][] grid) {
        boolean[][] copy = new boolean[GRID_SIZE][GRID_SIZE];
        for (int y = 0; y < GRID_SIZE; y++) {
            System.arraycopy(grid[y], 0, copy[y], 0, GRID_SIZE);
        }
        return copy;
    }

    


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawGrid(g);
    }

    private void drawGrid(Graphics g) {
        for (int y = 0; y < GRID_SIZE; y++) {
            for (int x = 0; x < GRID_SIZE; x++) {
                if (currentState[y][x]) {
                    g.fillRect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                } else {
                    g.clearRect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                }
            }
        }
    }

    private void handleGridClick(MouseEvent e) {
        int x = e.getX() / CELL_SIZE;
        int y = e.getY() / CELL_SIZE;

        if (x >= 0 && x < GRID_SIZE && y >= 0 && y < GRID_SIZE) {
            currentState[y][x] = !currentState[y][x];
            repaint(); // No need for gridPanel.repaint(); we extend JPanel now
        }
    }
    
    public void nextGeneration() {
        boolean[][] newState = new boolean[GRID_SIZE][GRID_SIZE];
        
        // Iterate over each cell in the grid
        for (int y = 0; y < GRID_SIZE; y++) {
            for (int x = 0; x < GRID_SIZE; x++) {
                int liveNeighbors = countLiveNeighbors(x, y);
                
                // Apply the Game of Life rules
                if (currentState[y][x]) {
                    // Cell is alive
                    newState[y][x] = (liveNeighbors == 2 || liveNeighbors == 3);
                } else {
                    // Cell is dead
                    newState[y][x] = (liveNeighbors == 3);
                }
            }
        }
        
        // Update the current state with the new generation
        currentState = newState;
        
        // Redraw the grid with the updated state
        repaint();
    }

    private int countLiveNeighbors(int x, int y) {
        int liveNeighbors = 0;
        
        // Check all 8 possible neighbors
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0) continue;  // Skip the cell itself
                
                int neighborX = x + i;
                int neighborY = y + j;
                
                // Make sure the neighbor is within bounds
                if (neighborX >= 0 && neighborX < GRID_SIZE && neighborY >= 0 && neighborY < GRID_SIZE) {
                    if (currentState[neighborY][neighborX]) {
                        liveNeighbors++;
                    }
                }
            }
        }
        
        return liveNeighbors;
    }
    
 // Initializes the grid with random cells (alive or dead)
    public void initializeRandomGrid() {
        Random rand = new Random();
        
        // Iterate over each cell in the grid
        for (int y = 0; y < GRID_SIZE; y++) {
            for (int x = 0; x < GRID_SIZE; x++) {
                // Randomly set each cell to true (alive) or false (dead)
                currentState[y][x] = rand.nextBoolean();  // 50% chance for true (alive) or false (dead)
            }
        }
        repaint();  // Redraw the grid with the random state
    }
    
    
    // Method to go back to the previous state (previous step in simulation)
    public void previousStep() {
        if (!history.isEmpty()) {
            history.pop();  // Remove the current state
            if (!history.isEmpty()) {
                currentState = history.peek();  // Get the previous state from the history stack
                repaint();  // Redraw the grid with the previous state
            }
        }
    }

    // Method to reset the grid (all cells dead)
    public void resetGrid() {
        initializeStates();  // Reset the grid to initial state (all dead cells)
    }

}