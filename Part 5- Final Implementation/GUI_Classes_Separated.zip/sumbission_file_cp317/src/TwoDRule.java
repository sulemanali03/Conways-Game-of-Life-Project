public class TwoDRule {
    private final int gridSize;

    public TwoDRule(int gridSize) {
        this.gridSize = gridSize;
    }

    /**
     * Applies Conway's Game of Life rules (2D).
     * This is adapted from the old 2D nextGeneration() method.
     */
    public boolean[][] applyRuleTwoD(boolean[][] currentState) {
        boolean[][] newState = new boolean[gridSize][gridSize];

        for (int y = 0; y < gridSize; y++) {
            for (int x = 0; x < gridSize; x++) {
                int liveNeighbors = countLiveNeighbors(currentState, x, y);
                if (currentState[y][x]) {
                    newState[y][x] = (liveNeighbors == 2 || liveNeighbors == 3);
                } else {
                    newState[y][x] = (liveNeighbors == 3);
                }
            }
        }
        return newState;
    }

    private int countLiveNeighbors(boolean[][] state, int x, int y) {
        int liveNeighbors = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0) continue; // skip self
                int nx = x + i;
                int ny = y + j;
                if (nx >= 0 && nx < gridSize && ny >= 0 && ny < gridSize) {
                    if (state[ny][nx]) {
                        liveNeighbors++;
                    }
                }
            }
        }
        return liveNeighbors;
    }
}
