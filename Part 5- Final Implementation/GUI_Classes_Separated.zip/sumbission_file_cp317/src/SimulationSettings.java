/**
 * Stores the primary simulation parameters:
 * - gridSize
 * - whether 1D or 2D
 * - simulation delay
 * - game status (NEW or STARTED)
 * - display format (BLACK_WHITE or NUMBER)
 */
public class SimulationSettings {
    private int gridSize;
    private boolean oneDMode;
    private int simulationDelay;
    private CAPar.GameStatus gameStatus;
    private CAPar.DisplayFormat displayFormat;

    public SimulationSettings() {
        // Default values
        this.gridSize = 58;
        this.oneDMode = false;
        this.simulationDelay = 500;
        this.gameStatus = CAPar.GameStatus.NEW;
        this.displayFormat = CAPar.DisplayFormat.BLACK_WHITE;
    }

    public int getGridSize() {
        return gridSize;
    }

    public void setGridSize(int gridSize) {
        this.gridSize = gridSize;
    }

    public boolean isOneDMode() {
        return oneDMode;
    }

    public void setOneDMode(boolean oneDMode) {
        this.oneDMode = oneDMode;
    }

    public int getSimulationDelay() {
        return simulationDelay;
    }

    public void setSimulationDelay(int simulationDelay) {
        this.simulationDelay = simulationDelay;
    }

    public CAPar.GameStatus getGameStatus() {
        return gameStatus;
    }

    public void setGameStatus(CAPar.GameStatus gameStatus) {
        this.gameStatus = gameStatus;
    }

    public CAPar.DisplayFormat getDisplayFormat() {
        return displayFormat;
    }

    public void setDisplayFormat(CAPar.DisplayFormat displayFormat) {
        this.displayFormat = displayFormat;
    }
}
