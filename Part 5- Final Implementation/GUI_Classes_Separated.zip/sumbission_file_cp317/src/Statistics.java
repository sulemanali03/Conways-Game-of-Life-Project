/**
 * Computes various statistics about the grid.
 */
public class Statistics {

    /**
     * Returns the total number of alive cells in the given matrix.
     */
    public int getAliveCount(boolean[][] currentState) {
        int count = 0;
        int size = currentState.length;
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                if (currentState[y][x]) {
                    count++;
                }
            }
        }
        return count;
    }
}
