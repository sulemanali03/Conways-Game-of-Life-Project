import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * The main GUI class that sets up tabs, panels, and connects
 * all the other classes together. 
 */
public class GUI_FINAL {

    private volatile boolean isPlaying = false;
    private JLabel gridStatusLabel;
    private JLabel simulationStateLabel;
    
    private OneDRule oneD;
    private TwoDRule twoD;

    // Simple helper to update top labels (grid state, simulation state)
    private void updateStatusLabels(StateGrid gridPanel, SimulationSettings simSettings) {
        gridStatusLabel.setText("         Grid Status: " + simSettings.getGameStatus());
        simulationStateLabel.setText("            Simulation State: " + (isPlaying ? "Active" : "Paused"));
    }

    // Stream to pipe System.out into a JTextArea
    public class TextAreaOutputStream extends java.io.OutputStream {
        private final JTextArea textArea;

        public TextAreaOutputStream(JTextArea textArea) {
            this.textArea = textArea;
        }

        @Override
        public void write(int b) {
            SwingUtilities.invokeLater(() -> {
                textArea.append(String.valueOf((char) b));
                textArea.setCaretPosition(textArea.getDocument().getLength());
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GUI_FINAL().createGUI());
    }

    private void createGUI() {
        JFrame frame = new JFrame("Conways Game of Life");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1220, 600);
        frame.setLayout(new BorderLayout());

        // Instantiate helper classes
        SimulationSettings simSettings = new SimulationSettings();
        VisualizationSettings visSettings = new VisualizationSettings();
        Statistics stats = new Statistics();
        GridStack tracker = new GridStack();
        
        // Initialize oneD and twoD using the current grid size
        oneD = new OneDRule(simSettings.getGridSize());
        twoD = new TwoDRule(simSettings.getGridSize());
        
        // Create the grid panel and pass the instance fields
        StateGrid gridPanel = new StateGrid(simSettings, visSettings, stats, tracker, oneD, twoD);
        frame.add(gridPanel, BorderLayout.WEST);

        // Tabbed Pane
        JTabbedPane tabbedPane = new JTabbedPane();

        /* --------------------- 
           1) Parameters Tab
           --------------------- */
        JPanel parametersPanel = new JPanel();
        parametersPanel.setLayout(new BoxLayout(parametersPanel, BoxLayout.Y_AXIS));

        // Simulation control buttons
        JPanel buttonPanel = new JPanel();
        JButton randomButton = new JButton("Initialize Random");
        JButton playPauseButton = new JButton("Play/Pause");
        JButton nextButton = new JButton("Next");
        JButton prevButton = new JButton("Previous");
        JButton resetButton = new JButton("Reset");
        buttonPanel.add(randomButton);
        buttonPanel.add(playPauseButton);
        buttonPanel.add(nextButton);
        buttonPanel.add(prevButton);
        buttonPanel.add(resetButton);
        parametersPanel.add(buttonPanel);

        // Status panel
        JPanel statusPanel = new JPanel(new GridLayout(2, 1));
        gridStatusLabel = new JLabel("Grid Status: NEW");
        simulationStateLabel = new JLabel("Simulation State: Paused");
        statusPanel.add(gridStatusLabel);
        statusPanel.add(simulationStateLabel);
        parametersPanel.add(statusPanel);

        // Grid dimension panel
        JPanel gridDimensionPanel = new JPanel();
        gridDimensionPanel.setBorder(BorderFactory.createTitledBorder("Grid Dimension"));
        JRadioButton rb1D = new JRadioButton("1D Grid", false);
        JRadioButton rb2D = new JRadioButton("2D Grid", true);
        ButtonGroup gridDimensionGroup = new ButtonGroup();
        gridDimensionGroup.add(rb1D);
        gridDimensionGroup.add(rb2D);
        gridDimensionPanel.add(rb1D);
        gridDimensionPanel.add(rb2D);
        parametersPanel.add(gridDimensionPanel);

        rb1D.addActionListener(e -> {
            if (simSettings.getGameStatus() != CAPar.GameStatus.NEW) {
                JOptionPane.showMessageDialog(frame, 
                        "Grid dimension can only be changed when the grid state is NEW.");
                rb2D.setSelected(true);
            } else {
                simSettings.setOneDMode(true);
            }
        });
        rb2D.addActionListener(e -> {
            if (simSettings.getGameStatus() != CAPar.GameStatus.NEW) {
                JOptionPane.showMessageDialog(frame, 
                        "Grid dimension can only be changed when the grid state is NEW.");
                rb2D.setSelected(true);
            } else {
                simSettings.setOneDMode(false);
            }
        });

        // Grid size slider
        JPanel gridSizePanel = new JPanel();
        gridSizePanel.setBorder(BorderFactory.createTitledBorder("Grid Size"));
        JSlider gridSizeSlider = new JSlider(5, 100, simSettings.getGridSize());
        gridSizeSlider.setPreferredSize(new Dimension(400, 50));
        gridSizeSlider.setPaintLabels(true);
        gridSizeSlider.setPaintTicks(true);
        gridSizeSlider.setMajorTickSpacing(10);
        gridSizePanel.add(gridSizeSlider);
        parametersPanel.add(gridSizePanel);

        gridSizeSlider.addChangeListener(e -> {
            int newGridSize = gridSizeSlider.getValue();
            if (simSettings.getGameStatus() != CAPar.GameStatus.NEW) {
                JOptionPane.showMessageDialog(frame, 
                        "Grid size can only be changed when the grid state is NEW.");
            } else {
                simSettings.setGridSize(newGridSize);
                // re-instantiate OneDA and TwoDA with new size
                oneD = new OneDRule(newGridSize);
                twoD = new TwoDRule(newGridSize);
                // re-link them to the grid
                // easiest is to create a new StateGrid or just reassign:
                gridPanel.initializeStates();
            }
        });

        // Simulation speed slider
        JPanel speedPanel = new JPanel();
        speedPanel.setBorder(BorderFactory.createTitledBorder("Simulation Speed"));
        JSlider speedSlider = new JSlider(1, 10, 5);
        speedSlider.setPaintTicks(true);
        speedSlider.setMajorTickSpacing(1);
        speedSlider.setPaintLabels(true);
        JTextField speedTextField = new JTextField("Speed: " + speedSlider.getValue());
        speedTextField.setEditable(false);
        speedTextField.setHorizontalAlignment(JTextField.CENTER);
        speedTextField.setPreferredSize(new Dimension(100, 30));

        speedSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int sliderValue = speedSlider.getValue();
                speedTextField.setText("Speed: " + sliderValue);
                // your original logic:  delay = 1100 - (sliderValue * 100)
                simSettings.setSimulationDelay(1100 - (sliderValue * 100));
            }
        });
        speedPanel.add(speedSlider);
        speedPanel.add(speedTextField);
        parametersPanel.add(speedPanel);

        // Cell display format
        JPanel displayFormatPanel = new JPanel();
        displayFormatPanel.setBorder(BorderFactory.createTitledBorder("Cell Display Format"));
        JRadioButton rbBlackAndWhite = new JRadioButton("Black and White", true);
        JRadioButton rbNumberFormat = new JRadioButton("Number Format");
        ButtonGroup displayFormatGroup = new ButtonGroup();
        displayFormatGroup.add(rbBlackAndWhite);
        displayFormatGroup.add(rbNumberFormat);
        displayFormatPanel.add(rbBlackAndWhite);
        displayFormatPanel.add(rbNumberFormat);
        parametersPanel.add(displayFormatPanel);

        rbBlackAndWhite.addActionListener(e -> {
            if (simSettings.getGameStatus() != CAPar.GameStatus.NEW) {
                JOptionPane.showMessageDialog(frame, 
                        "Cell display format can only be changed when the grid state is NEW.");
                rbBlackAndWhite.setSelected(false);
            } else {
                simSettings.setDisplayFormat(CAPar.DisplayFormat.BLACK_WHITE);
            }
        });
        rbNumberFormat.addActionListener(e -> {
            if (simSettings.getGameStatus() != CAPar.GameStatus.NEW) {
                JOptionPane.showMessageDialog(frame, 
                        "Cell display format can only be changed when the grid state is NEW.");
                rbNumberFormat.setSelected(false);
            } else {
                simSettings.setDisplayFormat(CAPar.DisplayFormat.NUMBER);
            }
        });

        tabbedPane.addTab("Parameters", parametersPanel);

        /* ---------------------
           2) Visualization Tab
           --------------------- */
        JPanel visualizationPanel = new JPanel();
        visualizationPanel.setLayout(new BoxLayout(visualizationPanel, BoxLayout.Y_AXIS));

        // Alive color chooser
        JPanel aliveColorPanel = new JPanel();
        aliveColorPanel.setBorder(BorderFactory.createTitledBorder("Alive Cell Color"));
        JColorChooser aliveColorChooser = new JColorChooser(visSettings.getAliveColor());
        aliveColorChooser.getSelectionModel().addChangeListener(e -> {
            visSettings.setAliveColor(aliveColorChooser.getColor());
            gridPanel.repaint();
        });
        aliveColorPanel.add(aliveColorChooser);
        visualizationPanel.add(aliveColorPanel);

        // Dead color chooser
        JPanel deadColorPanel = new JPanel();
        deadColorPanel.setBorder(BorderFactory.createTitledBorder("Dead Cell Color"));
        JColorChooser deadColorChooser = new JColorChooser(visSettings.getDeadColor());
        deadColorChooser.getSelectionModel().addChangeListener(e -> {
            visSettings.setDeadColor(deadColorChooser.getColor());
            gridPanel.repaint();
        });
        deadColorPanel.add(deadColorChooser);
        visualizationPanel.add(deadColorPanel);

        tabbedPane.addTab("Visualization", visualizationPanel);

        /* ---------------------
           3) Statistics Tab
           --------------------- */
        JPanel statisticsPanel = new JPanel();
        statisticsPanel.setLayout(new BoxLayout(statisticsPanel, BoxLayout.Y_AXIS));
        JLabel deadCellsLabel = new JLabel("Dead Cells: 0");
        JLabel aliveCellsLabel = new JLabel("Alive Cells: 0");
        JLabel populationLabel = new JLabel("Population: 0");
        JLabel percentageLabel = new JLabel("Percentage of Grid Used: 0%");
        deadCellsLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        aliveCellsLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        populationLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        percentageLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        statisticsPanel.add(deadCellsLabel);
        statisticsPanel.add(aliveCellsLabel);
        statisticsPanel.add(populationLabel);
        statisticsPanel.add(percentageLabel);
        tabbedPane.addTab("Statistics", statisticsPanel);

        /* ---------------------
           4) Import/Export Tab
           --------------------- */
        JPanel importExportPanel = new JPanel();
        importExportPanel.setLayout(new BoxLayout(importExportPanel, BoxLayout.Y_AXIS));

        // Import/Export buttons
        JPanel ieButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton importButton = new JButton("Import");
        JButton exportButton = new JButton("Export");
        ieButtonPanel.add(importButton);
        ieButtonPanel.add(exportButton);
        importExportPanel.add(ieButtonPanel);
        importExportPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // File browser area
        JPanel fileBrowserPanel = new JPanel();
        fileBrowserPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        JPanel fileNamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        fileNamePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel nameLabel = new JLabel("File Name:");
        JTextField fileName = new JTextField();
        Dimension fnameSize = new Dimension(300, 25);
        fileName.setPreferredSize(fnameSize);
        fileName.setMaximumSize(fnameSize);
        fileNamePanel.add(nameLabel);
        fileNamePanel.add(fileName);

        JPanel pathPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pathPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel pathLabel = new JLabel("File Directory:");
        JTextField pathField = new JTextField();
        Dimension pathFieldSize = new Dimension(500, 25);
        pathField.setPreferredSize(pathFieldSize);
        pathField.setMaximumSize(pathFieldSize);
        pathPanel.add(pathLabel);
        pathPanel.add(pathField);

        JPanel browsePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        browsePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton browseButton = new JButton("Browse");
        browsePanel.add(browseButton);

        fileBrowserPanel.add(fileNamePanel);
        fileBrowserPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        fileBrowserPanel.add(pathPanel);
        fileBrowserPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        fileBrowserPanel.add(browsePanel);
        importExportPanel.add(fileBrowserPanel);

        // Messaging panel
        JPanel messagingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        browsePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextPane message = new JTextPane();
        message.setContentType("text/html");
        message.setEditable(false);
        message.setBackground(null);
        message.setPreferredSize(new Dimension(500, 50));
        messagingPanel.add(message, BorderLayout.CENTER);
        importExportPanel.add(messagingPanel);

        ImportExport importExport = new ImportExport();

        // Browse button
        browseButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int returnValue = fileChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                java.io.File selectedFile = fileChooser.getSelectedFile();
                pathField.setText(selectedFile.getAbsolutePath());
            }
        });

        // Import button
        importButton.addActionListener(e -> {
            String file_path = pathField.getText();
            String file_name = fileName.getText();
            String result = importExport.doImport(file_path, file_name, isPlaying,
                    message, gridPanel, simSettings, stats, 0, 0);
            message.setText("<html><div style='width: 450px'>" + result + "</div></html>");
        });

        // Export button
        exportButton.addActionListener(e -> {
            String dir_path = pathField.getText();
            String file_name2 = fileName.getText();
            String result = importExport.doExport(dir_path, file_name2, isPlaying,
                    message, gridPanel, simSettings);
            message.setText("<html><div style='width: 450px'>" + result + "</div></html>");
        });

        tabbedPane.addTab("Import/Export", importExportPanel);

        /* ---------------------
           5) Execution Log Tab
           --------------------- */
        JPanel executionLogPanel = new JPanel(new BorderLayout());
        JTextArea logTextArea = new JTextArea();
        logTextArea.setEditable(false);
        JScrollPane logScrollPane = new JScrollPane(logTextArea);
        executionLogPanel.add(logScrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Execution Log", executionLogPanel);

        // Add the tabbed pane to the frame
        tabbedPane.setPreferredSize(new Dimension(600, frame.getHeight()));
        frame.add(tabbedPane, BorderLayout.EAST);

        // Redirect System.out to our text area
        System.setOut(new java.io.PrintStream(new TextAreaOutputStream(logTextArea)));

        /* ---------------------
           Button ActionListeners
           --------------------- */
        randomButton.addActionListener(e -> {
            if (!isPlaying) {
                gridPanel.randomizeGrid();
                updateStatusLabels(gridPanel, simSettings);
                updateStatistics(gridPanel, stats, deadCellsLabel, aliveCellsLabel, populationLabel, percentageLabel);
            } else {
                JOptionPane.showMessageDialog(frame, 
                        "Cannot initialize random grid while simulation is active (pause first).");
            }
        });

        nextButton.addActionListener(e -> {
            if (!isPlaying) {
                gridPanel.applyNextGeneration();
                updateStatusLabels(gridPanel, simSettings);
                updateStatistics(gridPanel, stats, deadCellsLabel, aliveCellsLabel, populationLabel, percentageLabel);
            } else {
                JOptionPane.showMessageDialog(frame, 
                        "Cannot go to next step while simulation is active (pause first).");
            }
        });

        prevButton.addActionListener(e -> {
            if (!isPlaying) {
                gridPanel.undoStep();
                updateStatusLabels(gridPanel, simSettings);
                updateStatistics(gridPanel, stats, deadCellsLabel, aliveCellsLabel, populationLabel, percentageLabel);
            } else {
                JOptionPane.showMessageDialog(frame, 
                        "Cannot revert step while simulation is active (pause first).");
            }
        });

        resetButton.addActionListener(e -> {
            if (!isPlaying) {
                gridPanel.resetGrid();
                updateStatusLabels(gridPanel, simSettings);
                updateStatistics(gridPanel, stats, deadCellsLabel, aliveCellsLabel, populationLabel, percentageLabel);
            } else {
                JOptionPane.showMessageDialog(frame, 
                        "Cannot reset while simulation is active (pause first).");
            }
        });

        playPauseButton.addActionListener(e -> {
            isPlaying = !isPlaying;
            if (isPlaying) {
                // Start a background thread to repeatedly call nextGeneration
                new Thread(() -> {
                    while (isPlaying) {
                        SwingUtilities.invokeLater(() -> {
                            gridPanel.applyNextGeneration();
                            updateStatusLabels(gridPanel, simSettings);
                            updateStatistics(gridPanel, stats, deadCellsLabel, aliveCellsLabel, populationLabel, percentageLabel);
                        });
                        try {
                            Thread.sleep(simSettings.getSimulationDelay());
                        } catch (InterruptedException ex) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }).start();
            }
            updateStatusLabels(gridPanel, simSettings);
        });

        frame.setVisible(true);
    }

    /**
     * Helper method to refresh the statistics labels.
     */
    private void updateStatistics(StateGrid gridPanel,
                                  Statistics stats,
                                  JLabel deadCellsLabel,
                                  JLabel aliveCellsLabel,
                                  JLabel populationLabel,
                                  JLabel percentageLabel) {

        boolean[][] matrix = gridPanel.getStateMatrix();
        int size = matrix.length;
        int totalCells = size * size;
        int aliveCount = stats.getAliveCount(matrix);
        int deadCount = totalCells - aliveCount;
        double percent = (aliveCount / (double) totalCells) * 100.0;

        deadCellsLabel.setText("Dead Cells: " + deadCount);
        aliveCellsLabel.setText("Alive Cells: " + aliveCount);
        populationLabel.setText("Population: " + aliveCount);
        percentageLabel.setText(String.format("Percentage of Grid Used: %.2f%%", percent));
    }
}
