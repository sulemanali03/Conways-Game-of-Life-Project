import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import javax.swing.JTextPane;

/**
 * Handles XML-based import/export of the cellular automaton state.
 */
public class ImportExport {

    /**
     * Imports an XML file, updates simulation settings and grid state.
     *
     * @return a message describing success or error
     */
    public String doImport(String path,
                           String fileName,
                           boolean isPlaying,
                           JTextPane message,
                           StateGrid stateGrid,
                           SimulationSettings simSettings,
                           Statistics stats,
                           int dummyAliveCells,
                           int dummyDeadCells) {

        if (isPlaying) {
            return "ERROR: please pause the simulation before importing.";
        }

        String xmlPath = path + "/" + fileName;
        if (!isValidPath(xmlPath) || !isValidFileName(fileName)) {
            return "ERROR: invalid path: " + xmlPath;
        }

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();

            Document doc = builder.parse(new File(xmlPath));
            doc.getDocumentElement().normalize();

            Element root = doc.getDocumentElement();
            if (!root.getTagName().equals("automata")) {
                throw new Exception("Invalid XML structure: root element must be 'automata'");
            }

            // Parse <settings>
            NodeList settingsList = root.getElementsByTagName("settings");
            if (settingsList.getLength() > 0) {
                Element settings = (Element) settingsList.item(0);

                // dimension
                int dimension = Integer.parseInt(getTagValue("dimension", settings));
                simSettings.setOneDMode(dimension == 1);

                // gridSize
                int gridSize = Integer.parseInt(getTagValue("gridSize", settings));
                simSettings.setGridSize(gridSize);
                stateGrid.initializeStates(); // reset the grid to new size

                // simSpeed
                int simSpeed = Integer.parseInt(getTagValue("simSpeed", settings));
                // your original code used (1100 - simSpeed*100) logic
                simSettings.setSimulationDelay(1100 - (simSpeed * 100));

                // display format
                String dispFormat = getTagValue("dispFormat", settings);
                if (dispFormat.equalsIgnoreCase("Black and White")) {
                    simSettings.setDisplayFormat(CAPar.DisplayFormat.BLACK_WHITE);
                } else {
                    simSettings.setDisplayFormat(CAPar.DisplayFormat.NUMBER);
                }
            }

            // parse <stats> (optional if needed)
            // parse <stategrid>
            NodeList stateGridList = root.getElementsByTagName("stategrid");
            if (stateGridList.getLength() > 0) {
                Element sg = (Element) stateGridList.item(0);
                Element matrix = (Element) sg.getElementsByTagName("matrix").item(0);
                NodeList rows = matrix.getElementsByTagName("row");

                boolean[][] newStateMatrix = new boolean[simSettings.getGridSize()][simSettings.getGridSize()];
                for (int i = 0; i < rows.getLength(); i++) {
                    Node row = rows.item(i);
                    String[] values = row.getTextContent().split(",");
                    for (int j = 0; j < values.length; j++) {
                        newStateMatrix[i][j] = values[j].trim().equals("1");
                    }
                }
                stateGrid.setStateMatrix(newStateMatrix);
            }

            return "XML file successfully parsed.";
        } catch (Exception err) {
            return "Error parsing XML file: " + err.getMessage();
        }
    }

    /**
     * Exports the current simulation settings and grid state to an XML file.
     *
     * @return a message describing success or error
     */
    public String doExport(String dirPath,
                           String fileName,
                           boolean isPlaying,
                           JTextPane message,
                           StateGrid stateGrid,
                           SimulationSettings simSettings) {

        if (isPlaying) {
            return "ERROR: please pause the simulation before exporting.";
        }

        String xmlPath = dirPath + "/" + fileName;
        if (!isValidPath(dirPath)) {
            return "ERROR: directory does not exist: " + dirPath;
        }
        if (isValidPath(xmlPath)) {
            return "ERROR: file already exists. Please create a new one.";
        }
        if (!isValidFileName(fileName)) {
            return "ERROR: invalid file name: " + fileName;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(xmlPath))) {
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            writer.newLine();
            writer.write("<automata>");
            writer.newLine();

            // <settings>
            writer.write("<settings>");
            writer.newLine();
            int dim = simSettings.isOneDMode() ? 1 : 2;
            writer.write(String.format("    <dimension>%d</dimension>", dim));
            writer.newLine();

            int gridSize = simSettings.getGridSize();
            writer.write(String.format("    <gridSize>%d</gridSize>", gridSize));
            writer.newLine();

            // For simplicity, let’s guess the user’s speed slider is 5 => so simSpeed=5
            // Or you could store the actual slider value in simSettings separately
            int simSpeed = 5;
            writer.write(String.format("    <simSpeed>%d</simSpeed>", simSpeed));
            writer.newLine();

            CAPar.DisplayFormat df = simSettings.getDisplayFormat();
            String display_fmt = (df == CAPar.DisplayFormat.BLACK_WHITE) ? "Black and White" : "Number Format";
            writer.write(String.format("    <dispFormat>%s</dispFormat>", display_fmt));
            writer.newLine();

            // ruleNumber (not actively used, but we store it)
            writer.write("    <ruleNumber>30</ruleNumber>");
            writer.newLine();
            writer.write("</settings>");
            writer.newLine();

            // <stats>
            writer.write("<stats>");
            writer.newLine();
            boolean[][] matrix = stateGrid.getStateMatrix();
            int aliveCount = 0;
            for (int y = 0; y < gridSize; y++) {
                for (int x = 0; x < gridSize; x++) {
                    if (matrix[y][x]) {
                        aliveCount++;
                    }
                }
            }
            int deadCount = (gridSize * gridSize) - aliveCount;
            writer.write(String.format("    <deadCells>%d</deadCells>", deadCount));
            writer.newLine();
            writer.write(String.format("    <aliveCells>%d</aliveCells>", aliveCount));
            writer.newLine();
            writer.write("    <population>0</population>");
            writer.newLine();
            writer.write("    <gridPercentage>0</gridPercentage>");
            writer.newLine();
            writer.write("</stats>");
            writer.newLine();

            // <stategrid>
            writer.write("<stategrid>");
            writer.newLine();
            writer.write("    <matrix>");
            writer.newLine();
            for (int i = 0; i < gridSize; i++) {
                writer.write("        <row>");
                StringBuilder rowData = new StringBuilder();
                for (int j = 0; j < gridSize; j++) {
                    if (j > 0) rowData.append(",");
                    int val = matrix[i][j] ? 1 : 0;
                    rowData.append(val);
                }
                writer.write(rowData.toString());
                writer.write("</row>");
                writer.newLine();
            }
            writer.write("    </matrix>");
            writer.newLine();
            writer.write("</stategrid>");
            writer.newLine();

            writer.write("</automata>");
            return "Results successfully written to " + xmlPath;
        } catch (IOException err) {
            return "ERROR: Failed to write to file: " + err.getMessage();
        }
    }

    // Helper methods
    private boolean isValidPath(String path) {
        File f = new File(path);
        return f.exists();
    }

    private boolean isValidFileName(String fname) {
        if (fname == null || fname.isEmpty()) {
            return false;
        }
        if (!fname.endsWith(".xml")) {
            return false;
        }
        String invalidChars = "\\/:*?\"<>|";
        for (char c : invalidChars.toCharArray()) {
            if (fname.indexOf(c) != -1) {
                return false;
            }
        }
        return true;
    }

    private String getTagValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag);
        if (nodeList != null && nodeList.getLength() > 0) {
            Node node = nodeList.item(0);
            if (node.hasChildNodes()) {
                return node.getFirstChild().getNodeValue().trim();
            }
        }
        throw new RuntimeException("Tag not found or empty: " + tag);
    }
}
