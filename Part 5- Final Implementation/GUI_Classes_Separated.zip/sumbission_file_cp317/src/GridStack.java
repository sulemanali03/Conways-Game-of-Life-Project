import java.util.Stack;

/**
 * Manages a stack of states (boolean[][]) so that the simulation
 * can revert to previous steps. (Sometimes called TrackDA / TExcDA)
 */
public class GridStack {
    private final Stack<boolean[][]> history;

    public GridStack() {
        history = new Stack<>();
    }

    public void pushState(boolean[][] state) {
        history.push(copyGrid(state));
    }

    /**
     * Pop the current state off the stack and return the previous state.
     * If no previous state exists, return null.
     */
    public boolean[][] popState() {
        if (!history.isEmpty()) {
            history.pop(); // remove the current
        }
        if (!history.isEmpty()) {
            return copyGrid(history.peek()); // the previous
        }
        return null;
    }

    public boolean[][] peekState() {
        if (!history.isEmpty()) {
            return history.peek();
        }
        return null;
    }

    public void clear() {
        history.clear();
    }

    private boolean[][] copyGrid(boolean[][] grid) {
        if (grid == null) return null;
        int size = grid.length;
        boolean[][] copy = new boolean[size][size];
        for (int i = 0; i < size; i++) {
            System.arraycopy(grid[i], 0, copy[i], 0, size);
        }
        return copy;
    }
}
