
public class OneDRule {
    private int activeRow;
    private final int gridSize;

    public OneDRule(int gridSize) {
        this.gridSize = gridSize;
        this.activeRow = 0;
    }

    public int getActiveRow() {
        return activeRow;
    }

    public void setActiveRow(int row) {
        this.activeRow = row;
    }

    /**
     * Applies Rule 30 logic to the currentState (1D).
     * This is adapted from the old processNextGeneration1D() method.
     * 
     * @param currentState the current 2D array
     * @return a new 2D boolean array after applying Rule 30 on the "active row"
     */
    public boolean[][] applyRuleOneD(boolean[][] currentState) {
        int size = currentState.length;
        boolean[][] newState = copyGrid(currentState);

        // Build the new row based on the current active row
        boolean[] newRow = new boolean[size];
        for (int x = 0; x < size; x++) {
            boolean left   = (x == 0)            ? false : currentState[activeRow][x - 1];
            boolean center =                       currentState[activeRow][x];
            boolean right  = (x == size - 1)    ? false : currentState[activeRow][x + 1];

            int pattern = (left ? 4 : 0) + (center ? 2 : 0) + (right ? 1 : 0);

            // Rule 30 mapping
            switch (pattern) {
                case 7: newRow[x] = false; break; // 111 -> 0
                case 6: newRow[x] = false; break; // 110 -> 0
                case 5: newRow[x] = false; break; // 101 -> 0
                case 4: newRow[x] = true;  break; // 100 -> 1
                case 3: newRow[x] = true;  break; // 011 -> 1
                case 2: newRow[x] = true;  break; // 010 -> 1
                case 1: newRow[x] = true;  break; // 001 -> 1
                case 0: newRow[x] = false; break; // 000 -> 0
            }
        }

        // Insert the new row into the grid
        if (activeRow < size - 1) {
            for (int x = 0; x < size; x++) {
                newState[activeRow + 1][x] = newRow[x];
            }
            activeRow++;
        } else {
            // If at the bottom, scroll the grid upward
            for (int row = 0; row < size - 1; row++) {
                newState[row] = newState[row + 1];
            }
            newState[size - 1] = newRow;
        }
        return newState;
    }

    private boolean[][] copyGrid(boolean[][] grid) {
        int size = grid.length;
        boolean[][] copy = new boolean[size][size];
        for (int i = 0; i < size; i++) {
            System.arraycopy(grid[i], 0, copy[i], 0, size);
        }
        return copy;
    }
}
