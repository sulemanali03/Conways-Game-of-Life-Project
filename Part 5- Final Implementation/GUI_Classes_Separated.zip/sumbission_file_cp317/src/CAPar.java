public class CAPar {
    // Enums moved out of the old code for shared usage
    public enum GameStatus {
        NEW, STARTED
    }

    public enum DisplayFormat {
        BLACK_WHITE, NUMBER
    }
}
