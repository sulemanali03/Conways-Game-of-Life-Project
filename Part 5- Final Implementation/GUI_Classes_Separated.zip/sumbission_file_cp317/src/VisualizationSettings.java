import java.awt.Color;

/**
 * Holds color and display-format settings for the grid.
 */
public class VisualizationSettings {
    private Color aliveColor;
    private Color deadColor;

    public VisualizationSettings() {
        // Default to black (alive) and white (dead)
        this.aliveColor = Color.BLACK;
        this.deadColor = Color.WHITE;
    }

    public Color getAliveColor() {
        return aliveColor;
    }

    public void setAliveColor(Color aliveColor) {
        this.aliveColor = aliveColor;
    }

    public Color getDeadColor() {
        return deadColor;
    }

    public void setDeadColor(Color deadColor) {
        this.deadColor = deadColor;
    }
}
