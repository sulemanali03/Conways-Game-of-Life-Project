import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

/**
 * The core panel that displays the grid and delegates:
 * - 1D logic to OneDA
 * - 2D logic to TwoDA
 * - tracking to TExcDA
 * - stats to Statistics
 * - settings to SimulationSettings
 * - colors to VisualizationSettings
 */
public class StateGrid extends JPanel {

    private boolean[][] currentState;
    private final SimulationSettings simSettings;
    private final VisualizationSettings visSettings;
    private final Statistics stats;
    private final GridStack tracker;
    private OneDRule oneD;
    private TwoDRule twoD;

    private int cellSize = 600 / 58; // default if gridSize=58

    public StateGrid(SimulationSettings simSettings,
                     VisualizationSettings visSettings,
                     Statistics stats,
                     GridStack tracker,
                     OneDRule oneD,
                     TwoDRule twoD) {
        this.simSettings = simSettings;
        this.visSettings = visSettings;
        this.stats = stats;
        this.tracker = tracker;
        this.oneD = oneD;
        this.twoD = twoD;

        setPreferredSize(new Dimension(600, 600));
        initializeStates();

        // Toggle cell alive/dead on click
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleGridClick(e);
            }
        });
    }

    // Initialize the grid to all-dead cells
    public void initializeStates() {
        int gSize = simSettings.getGridSize();
        currentState = new boolean[gSize][gSize];
        tracker.clear();
        tracker.pushState(currentState);
        simSettings.setGameStatus(CAPar.GameStatus.NEW);

        recalcCellSize();
        repaint();
    }

    // Recalculate the cell size so the grid always fits in 600x600
    private void recalcCellSize() {
        cellSize = 600 / simSettings.getGridSize();
    }

    // Return a copy of the current state
    public boolean[][] getStateMatrix() {
        return copyGrid(currentState);
    }

    // Replace the entire grid state
    public void setStateMatrix(boolean[][] matrix) {
        if (matrix != null && matrix.length == matrix[0].length) {
            currentState = copyGrid(matrix);
            tracker.clear();
            tracker.pushState(currentState);
            simSettings.setGameStatus(CAPar.GameStatus.NEW);
            repaint();
        }
    }

    // Randomize the grid
    public void randomizeGrid() {
        int gSize = simSettings.getGridSize();
        Random rand = new Random();
        for (int y = 0; y < gSize; y++) {
            for (int x = 0; x < gSize; x++) {
                currentState[y][x] = rand.nextBoolean();
            }
        }
        simSettings.setGameStatus(CAPar.GameStatus.STARTED);
        repaint();
    }

    // Evolve the grid by one generation (calls either OneDA or TwoDA)
    public void applyNextGeneration() {
        boolean[][] newState;
        if (simSettings.isOneDMode()) {
            // 1D logic
            // update the OneDA object to reflect the active row if needed
            oneD.setActiveRow(findActiveRow(currentState));
            newState = oneD.applyRuleOneD(currentState);
        } else {
            // 2D logic
            newState = twoD.applyRuleTwoD(currentState);
        }

        if (simSettings.getGameStatus() == CAPar.GameStatus.NEW) {
            simSettings.setGameStatus(CAPar.GameStatus.STARTED);
        }
        tracker.pushState(newState);
        currentState = newState;
        repaint();
    }

    // Attempt to revert to a previous step
    public void undoStep() {
        boolean[][] prev = tracker.popState();
        if (prev != null) {
            currentState = prev;
            repaint();
        }
    }

    // Reset the grid entirely
    public void resetGrid() {
        initializeStates();
    }

    // Handle cell toggling on mouse click
    private void handleGridClick(MouseEvent e) {
        int x = e.getX() / cellSize;
        int y = e.getY() / cellSize;
        int gSize = simSettings.getGridSize();
        if (x >= 0 && x < gSize && y >= 0 && y < gSize) {
            currentState[y][x] = !currentState[y][x];
            if (simSettings.getGameStatus() == CAPar.GameStatus.NEW) {
                simSettings.setGameStatus(CAPar.GameStatus.STARTED);
            }
            repaint();
        }
    }

    // A helper to guess the active row in 1D (if needed)
    private int findActiveRow(boolean[][] state) {
        // Minimal approach: let OneDA store the row. 
        // If you want a more robust approach, find the last non-empty row.
        return oneD.getActiveRow();
    }

    // Paint the grid
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawGrid(g);
    }

    private void drawGrid(Graphics g) {
        int gSize = simSettings.getGridSize();
        CAPar.DisplayFormat format = simSettings.getDisplayFormat();

        if (format == CAPar.DisplayFormat.BLACK_WHITE) {
            for (int y = 0; y < gSize; y++) {
                for (int x = 0; x < gSize; x++) {
                    g.setColor(currentState[y][x] ? visSettings.getAliveColor()
                                                   : visSettings.getDeadColor());
                    g.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
                }
            }
        } else if (format == CAPar.DisplayFormat.NUMBER) {
            // White background
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(Color.BLACK);

            Font originalFont = g.getFont();
            Font numberFont = originalFont.deriveFont(Font.BOLD, cellSize / 2);
            g.setFont(numberFont);

            for (int y = 0; y < gSize; y++) {
                for (int x = 0; x < gSize; x++) {
                    String text = currentState[y][x] ? "1" : "0";
                    int cellX = x * cellSize;
                    int cellY = y * cellSize;
                    g.drawString(text, cellX + cellSize / 4, 
                                       cellY + (cellSize * 3) / 4);
                }
            }
            g.setFont(originalFont);
        }
    }

    private boolean[][] copyGrid(boolean[][] grid) {
        int size = grid.length;
        boolean[][] copy = new boolean[size][size];
        for (int y = 0; y < size; y++) {
            System.arraycopy(grid[y], 0, copy[y], 0, size);
        }
        return copy;
    }
}
